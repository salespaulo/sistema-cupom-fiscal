
package sat;


/**
 *
 * @author Wellington Felix Martins
 */
public class TelaSistema {


    public static void main(String[] args) {
          TelaSAT ger =new TelaSAT();
       ger.setVisible(true);
        
    }
    
}
